# ✅ VELLO Message Sending - COMPLETE FIX

## 🔍 Root Cause Found

Your app tries to insert a Message into Supabase, but the **`created_at` field is missing or null**. 

The database table definition is:
```sql
CREATE TABLE public.messages (
    id BIGINT PRIMARY KEY IDENTITY,
    chat_id UUID NOT NULL,
    sender_id UUID NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),  ← Database expects this!
    status TEXT DEFAULT 'SENT'
)
```

When your app sends a message **without** `created_at`, the database insert fails silently (caught by try/catch in your code, but no visible error to the user).

---

## 🛠️ Fix (2 Simple Steps)

### Step 1: Update Your Message Model

**File:** `app/src/main/java/com/mr10/vello/data/model/Message.kt`

**Replace the entire file with:**

```kotlin
package com.mr10.vello.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Message(
    val id: Long? = null,
    @SerialName("chat_id")
    val chatId: String,
    @SerialName("sender_id")
    val senderId: String,
    val content: String,
    @SerialName("created_at")
    val created_at: String? = null,  // ✅ ADD THIS LINE
    val status: MessageStatus = MessageStatus.SENT
)

enum class MessageStatus(val value: String) {
    PENDING("PENDING"),
    SENT("SENT"),
    DELIVERED("DELIVERED"),
    READ("READ")
}
```

**Key change:** Add the `@SerialName("created_at")` field with optional String type.

---

### Step 2: Update ChatRepositoryImpl

**File:** `app/src/main/java/com/mr10/vello/data/repository/ChatRepositoryImpl.kt`

**Find this function (around line 48):**

```kotlin
override suspend fun sendMessage(message: Message) {
    try {
        postgrest["messages"].insert(message)
        Log.d("ChatRepository", "Message insert successful")
    } catch (e: RestException) {
        Log.e("ChatRepository", "Supabase Rest Error: ${e.message}")
        throw e
    } catch (e: Exception) {
        Log.e("ChatRepository", "Unexpected error sending message: ${e.message}", e)
        throw e
    }
}
```

**Replace it with:**

```kotlin
override suspend fun sendMessage(message: Message) {
    try {
        // ✅ FIX: Ensure created_at is set to current timestamp
        val messageToSend = if (message.created_at == null) {
            message.copy(created_at = java.time.Instant.now().toString())
        } else {
            message
        }

        Log.d("ChatRepository", "Sending message: chatId=${messageToSend.chatId}, senderId=${messageToSend.senderId}, content=${messageToSend.content}, created_at=${messageToSend.created_at}")
        
        postgrest["messages"].insert(messageToSend)
        Log.d("ChatRepository", "Message insert successful")
    } catch (e: RestException) {
        Log.e("ChatRepository", "Supabase Rest Error: ${e.message}")
        Log.e("ChatRepository", "Error body: ${e.errorBody}")  // ✅ Better debugging
        throw e
    } catch (e: Exception) {
        Log.e("ChatRepository", "Unexpected error sending message: ${e.message}", e)
        throw e
    }
}
```

**What changed:**
- ✅ Set `created_at` to current timestamp before sending
- ✅ Added detailed logging so you can see what's being sent
- ✅ Added `e.errorBody` logging to see real error details

---

## 📋 Verification Checklist

After making these changes:

- [ ] Edit `Message.kt` - add the `created_at` field
- [ ] Edit `ChatRepositoryImpl.kt` - update `sendMessage()` to set timestamp
- [ ] Rebuild the app: **Build → Rebuild Project**
- [ ] Clean build cache: **Build → Clean Project**
- [ ] Run on emulator/device
- [ ] Try sending a message
- [ ] Check Logcat for: `"Message insert successful"` (success) or error details

---

## 🔧 Optional: Better Error Handling

If you still see errors after this fix, you can add a Toast to show the user what went wrong.

**In ChatViewModel.kt, update the catch block:**

```kotlin
} catch (e: Exception) {
    Log.e("ChatViewModel", "Failed to send message: ${e.message}", e)
    
    // ✅ NEW: Show error to user (add this)
    android.widget.Toast.makeText(
        android.content.Context,
        "Failed to send message: ${e.message}",
        android.widget.Toast.LENGTH_SHORT
    ).show()
    
    _messages.value = _messages.value.map { 
        if (it == pendingMessage) it.copy(status = MessageStatus.PENDING)
        else it
    }
}
```

---

## 🚀 After the Fix

**Expected behavior:**
1. User types message and taps send
2. Message appears in UI immediately (pending status)
3. Message is sent to Supabase with `created_at` timestamp
4. Message status changes to SENT
5. Message persists in database

**If still not working:**
1. Check Logcat - look for actual error message
2. Verify Supabase credentials in `VelloApplication.kt`
3. Verify user is authenticated (can you load chats?)
4. Check RLS policies in Supabase dashboard

---

## 📊 Database Fix (Already Done ✅)

The database RLS policies have already been fixed to allow authenticated users to insert messages. You just needed the client-side timestamp field.

---

## Questions?

If messages still don't send after this:
1. Share the Logcat output (screenshot or paste)
2. Show the exact error message from the Toast or Logcat
3. Verify the user is logged in and can load chats
